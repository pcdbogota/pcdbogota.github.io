#use_osc "localhost", 12000

use_bpm 86


live_loop :bumbum do
  sample :bd_haus
  note = rand_i 30..60
  x = rrand_i(1,540) # 255/30*(note-30)
  #osc "/pallado", x
  sleep 1
end

live_loop :dembow do
  y = rrand_i(1,960)
  sleep 0.75
  #sample :loop_amen, beat_stretch: 3, start: 0.25, finish: 0.35
  #osc "/pabajo", y
  sleep 0.75
  #sample :sn_dub
  #osc "/pabajo", y/rrand_i(1,y)
  sleep 0.25
  #sample :loop_amen, beat_stretch: 2, start: 0.25, finish: 1, amp: 0.5
  #osc "/pabajo", y/3
  sleep 0.25
end


reggae = (ring :r, chord(:E3, :m), :r, chord(:E3, :m), :r, chord(:A3, :m7), :r, chord(:A3, :m7), :r, chord(:B3, :m), :r, chord(:B3, :m), :r, chord(:E3, :m7), :r, chord(:E3, :m7))
live_loop :arp do
  with_fx :echo, phase: 0.3 do
    use_synth :dpulse
    #play reggae.tick, release: 0.2
    sleep 0.5
  end
end

use_synth :tb303
live_loop :squelch do
  nivel = 1
  n = (ring :e1, :a2, :b1, :e1).tick
  #play n, attack: 0.015, cutoff: 50, amp: nivel
  sleep 1
  #play n, attack: 0.015, cutoff: 50, amp: nivel
  sleep 0.5
  #play n, attack: 0.015, cutoff: 50, amp: nivel
  sleep 0.5
end

suave = (ring :r, chord(:E3, :m), :r, chord(:A3, :m7), :r, chord(:B3, :m), :r, chord(:E3, :m7))
live_loop :suaveseo do
  use_synth :prophet
  #play suave.tick, attack: 0.5, decay: 0.5, sustain: 0.5, release: 1, amp: 0.3
  sleep 1
end

live_loop :puroriqueo do
  with_fx :reverb, room: 0.8, mix: 0.2 do
    use_random_seed 1
    use_synth :dsaw
    notis = (scale :e2 , :aeolian, num_octaves: 3)
    16.times do
      #play notis.choose, attack: 0.2, release: 0.1, cutoff: rrand(50, 90), amp: 0.3, pan: rrand(-0.5, 0.5)
      sleep 0.25
    end
  end
end


